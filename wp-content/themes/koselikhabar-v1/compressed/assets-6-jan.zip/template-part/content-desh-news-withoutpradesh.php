<section class="desh_news">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12">
                <div class="row theme_color">
                    <div class="col-12">
                        देश
                    </div>
                </div>
                <div class="row">

                <?php
                    global $wp_query;
                    $v = 1;
                    $deshNews = array(
                            'post_type' =>  'desh_news',
                            'post_per_page' =>  5,
                            'order' =>  'desc',
                    );
                    query_posts($deshNews);
                    $count = $wp_query->found_posts;
                    if (have_posts()) :
                        while(have_posts()): the_post(); ?>
                        <?php
                            if($v ==1){?>
                                <div class="col-md-6 col-sm-12">
                                    <div class="main_news">
                                        <div class="featured_image">
                                            <img src="<?php echo the_post_thumbnail_url('medium'); ?>" alt="...">
                                        </div>
                                        <div class="news_detail">
                                            <h5 class="news_title">
                                                <a href="<?php the_permalink();?>" title="<?php echo get_the_title();?>">
                                                    <?php the_title();?>
                                                </a>
                                            </h5>
                                            <div class="publish_time">
                                                <i class="fa fa-calendar"></i><?php echo get_the_time();?>
                                            </div>
                                            <div class="news_desc">
                                                <?php
                                                $content = strip_tags(get_the_content());
                                                if(has_excerpt( $post->ID )){
                                                    the_excerpt();
                                                } else{
                                                    echo '<p>'.wp_trim_words($content,'25', '....').'</p>';
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        <?php
                            }
                            if($v == 2){
                                echo '<div class="col-md-6 col-sm-12">
                                            <div class="main_side_news">
                                                <div class="row">';
                            }
                            if($v>1){?>
                                <div class="col-6">
                                    <div class="featured_image">
                                        <img src="<?php echo the_post_thumbnail_url('small'); ?>" alt="adfs"/>
                                    </div>
                                    <div class="news_detail">
                                        <h5 class="news_title">
                                            <a href="<?php the_permalink();?>" title="<?php echo get_the_title();?>">
                                                <?php the_title();?>
                                            </a>
                                        </h5>
                                        <div class="publish_time">
                                            <i class="fa fa-calendar"></i><?php echo get_the_time();?>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            if($v==5 || $v == $count){
                                echo '</div>
                                    </div>
                                </div>';
                            }
                        ?>


                    <?php
                            $v++;
                        endwhile;
                    endif;
                    ?>

                </div>


                <!--Video Start-->
                <?php
                $video = array(
                    'post_type' =>  'videos',
                    'posts_per_page' => 1,
                    'order' => 'desc'
                );
                query_posts($video);
                if (have_posts()) :
                ?>
                <div class="row">
                    <div class="col-12">
                        <div class="latestvideo">
                            <?php
                            while (have_posts()) : the_post();
                            ?>
                            <iframe width="100%" height="400px" src="<?php echo get_post_meta($post->ID, "_youtubelink", true); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                            <?php
                            endwhile;
                            ?>
                        </div>
                    </div>
                </div>
                <?php
                    endif;
                ?>
            </div>
            <div class="col-md-3 col-sm-12">
                <div class="row theme_color">
                    <div class="col-12">
                        ट्रेन्डिङ
                    </div>
                </div>
                <div class="trending">
                    <?php
                    for ($i = 1; $i <= 5; $i++) {
                        ?>
                        <div class="row padding_x_1rem">
                            <div class="col-md-3 trending_num">
                                <span class="fontSize_34px"><?php echo $i ?></span>
                            </div>
                            <div class="col-md-9 col-sm-12">
                                <img src="https://picsum.photos/200/100" width="100%" alt="adfs"/>
                            </div>
                        </div>
                    <?php }
                    ?>

                </div>

            </div>
        </div>
    </div>
</section>