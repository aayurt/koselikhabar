<section class="latest-news">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-7 col-sm-12">
                        <div class="main_news">
                            <div class="featured_image">
                                <img src="https://picsum.photos/200/150" class="card-img-top" alt="...">
                            </div>
                            <div class="news_detail">
                                <h5 class="news_title">
                                    <a href="single.php">
                                        शोक प्रस्ताव पारित गरेपछि नेकपा बैठक स्थगित हुने
                                    </a>
                                </h5>
                                <div class="publish_time">
                                    <i class="fa fa-calendar"></i>Publish Time
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-5">
                        <ul class="main_side_news">
                            <li>
                                <div class="row ">
                                    <div class="col-5">
                                        <div class="featured_image">
                                            <img src="https://picsum.photos/200/150" alt="adfs"/>
                                        </div>
                                    </div>
                                    <div class="col-7">
                                        <div class="news_detail">
                                            <h5 class="news_title">
                                                <a href="single.php">
                                                    शोक प्रस्ताव पारित गरेपछि नेकपा बैठक स्थगित हुने
                                                </a>
                                            </h5>
                                            <div class="publish_time">
                                                <i class="fa fa-calendar"></i>Publish Time
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row ">
                                    <div class="col-5">
                                        <div class="featured_image">
                                            <img src="https://picsum.photos/200/150" alt="adfs"/>
                                        </div>
                                    </div>
                                    <div class="col-7">
                                        <div class="news_detail">
                                            <h5 class="news_title">
                                                <a href="single.php">
                                                    शोक प्रस्ताव पारित गरेपछि नेकपा बैठक स्थगित हुने
                                                </a>
                                            </h5>
                                            <div class="publish_time">
                                                <i class="fa fa-calendar"></i>Publish Time
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row ">
                                    <div class="col-5">
                                        <div class="featured_image">
                                            <img src="https://picsum.photos/200/150" alt="adfs"/>
                                        </div>
                                    </div>
                                    <div class="col-7">
                                        <div class="news_detail">
                                            <h5 class="news_title">
                                                <a href="single.php">
                                                    शोक प्रस्ताव पारित गरेपछि नेकपा बैठक स्थगित हुने
                                                </a>
                                            </h5>
                                            <div class="publish_time">
                                                <i class="fa fa-calendar"></i>Publish Time
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row ">
                                    <div class="col-5">
                                        <div class="featured_image">
                                            <img src="https://picsum.photos/200/150" alt="adfs"/>
                                        </div>
                                    </div>
                                    <div class="col-7">
                                        <div class="news_detail">
                                            <h5 class="news_title">
                                                <a href="single.php">
                                                    शोक प्रस्ताव पारित गरेपछि नेकपा बैठक स्थगित हुने
                                                </a>
                                            </h5>
                                            <div class="publish_time">
                                                <i class="fa fa-calendar"></i>Publish Time
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-12">
                <div class="ad-block">
                    <ul>
                        <li>
                            <img src="https://picsum.photos/200/200" alt="adfs"/>
                        </li>
                        <li>
                            <img src="https://picsum.photos/200/200" alt="adfs"/>
                        </li>
                        <li>
                            <img src="https://picsum.photos/200/200" alt="adfs"/>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>