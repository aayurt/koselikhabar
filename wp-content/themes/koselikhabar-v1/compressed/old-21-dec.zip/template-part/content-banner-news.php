<section class="banner-news">
    <div class="container">
        <?php
        for($i = 1; $i<=4;$i++){?>
            <div class="row">
                <div class="col-md-12">
                    <div class="news">
                        <div class="banner-news-title">
                            <h1>
                                <a href="single.php">
                                    चिडियाखाना खुल्यो, विद्यालय अझै बन्द !
                                </a>

                            </h1>
                        </div>
                        <div class="banner-news-detail">
                            <ul>
                                <li class="author_name"><i class="fa fa-user"></i>Author name</li>
                                <li class="publish_time"><i class="fa fa-clock-o"></i>Publish Time</li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        <?php }
        ?>

    </div>
</section>