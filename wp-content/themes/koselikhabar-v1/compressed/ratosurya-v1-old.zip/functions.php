<?php

$includes_path = TEMPLATEPATH . '/includes/';

require_once($includes_path . 'theme-functions.php');        // theme functions
require_once($includes_path . 'custom-post-functions.php');        // custom post types functions
require_once($includes_path . 'bootstrap_nav_walker.php');  // bootstrap menu walker