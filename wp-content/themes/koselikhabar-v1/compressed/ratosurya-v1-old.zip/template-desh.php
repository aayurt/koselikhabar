<?php
/*

Template Name: Desh News

*/
get_header();
?>

<?php
get_footer();
?>
